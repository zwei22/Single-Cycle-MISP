cycle time: 9.5
FPU Single: Y
FPU Double: Y
FPU cycle time: 55